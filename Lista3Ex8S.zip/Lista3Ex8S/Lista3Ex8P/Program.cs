﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3Ex8P
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double cntd = 0;
            double resul = 0;

            do
            {
                cntd++;
                resul = resul + cntd;
            }

            while (cntd < 100);
            Console.WriteLine("A soma de todos os números inteiros positivos que estão no intervalo de 1 à 100 é: {0}", resul);
        }
    }
}
