﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3Ex2P
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double n1 = 0;
            double n2 = 0;

            Console.Write("Informe o 1° valor desejado: ");
            n1 = double.Parse(Console.ReadLine());

            do
            {
                Console.Write("Informe o 2° valor desejado: ");
                n2 = double.Parse(Console.ReadLine());
            }
            while (n2 <= n1);
        }
    }
}
