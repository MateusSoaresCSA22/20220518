﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3Ex9P
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double cntd = 0;
            int n1 = 1;
            int n2 = 0;
            int n3 = 0;

            do
            {
                cntd++;
                n3 = n1 + n2;
                Console.Write("{0}, ", n3);
                n1 = n2;
                n2 = n3;
            }

            while (cntd < 30);
        }
    }
}
