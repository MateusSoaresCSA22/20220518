﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3Ex4P
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double val = 0;
            int cntd = 0;

            do
            {
                cntd++;
                val = 5 * cntd;
                Console.WriteLine("5 x {0} = {1}", cntd, val);
            }

            while (cntd < 10);
        }
    }
}
