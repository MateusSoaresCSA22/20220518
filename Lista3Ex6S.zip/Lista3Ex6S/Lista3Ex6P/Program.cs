﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3Ex6P
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double val = 0;
            double valorB = 0;
            double valorA = 0;
            double resul = 0;

           

            Console.WriteLine("Informe um valor para a tabuada:");
            val = double.Parse(Console.ReadLine());

            while (val <= 0)
            {
                Console.WriteLine("Informe o valor novamente, porém positivo:");
                val = double.Parse(Console.ReadLine());
            }

            Console.WriteLine("Informe o valor inicial do intervalo (A):");
            valorA = double.Parse(Console.ReadLine());

            Console.WriteLine("Informe o Valor Final do Intervalo (B):");
            valorB = double.Parse(Console.ReadLine());

            while (valorB <= valorA)
            {
                Console.WriteLine("Informe o valor final do intervalo novamente (B > A):");
                valorB = double.Parse(Console.ReadLine());
            }

            Console.WriteLine("\nTabuada do {0}, No Intervalo do {1} ao {2}\n", val, valorB, valorA);

            while (valorB >= valorA)
            {
                resul = val * valorB;
                Console.WriteLine("{0} x {1} = {2}", val, valorB, resul);
                valorB--;
            }
        }
    }
}
