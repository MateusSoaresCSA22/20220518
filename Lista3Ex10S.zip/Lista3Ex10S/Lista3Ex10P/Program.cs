﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3Ex10P
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double val;
            double maior = 0;
            double cntd = 0;
            double soma = 0;
            double mediarit;

            do
            {
                cntd++;
                Console.Write("Informe o {0}º valor: ", cntd);
                val = double.Parse(Console.ReadLine());
                while (val < 0)
                {
                    Console.WriteLine("Erro!");
                    Console.Write("Informe o {0}º Valor Novamente: ", cntd);
                    val = double.Parse(Console.ReadLine());
                }
                if (val > maior)
                {
                    maior = val;
                }
                soma = soma + val;
            }
            while (cntd < 10);
            mediarit = soma / 10;

            Console.WriteLine("");
            Console.WriteLine("Maior Valor: {0}", maior);
            Console.WriteLine("Soma dos Valores: {0}", soma);
            Console.WriteLine("Média dos Valores: {0}", mediarit);
        }
    }
}
