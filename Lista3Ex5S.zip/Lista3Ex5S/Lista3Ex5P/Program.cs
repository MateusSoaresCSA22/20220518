﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3Ex5P
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double val = 0;
            double resul = 0;
            int cntd = 0;

            do
            {
                Console.WriteLine("Informe um valor: ");
                val = double.Parse(Console.ReadLine());
            }
            while (val < 0);

            do
            {
                cntd++;
                resul = val * cntd;
                Console.WriteLine("{0} x {1} = {2}", cntd, val, resul);
            }
            while (cntd < 10);
        }
    }
}
