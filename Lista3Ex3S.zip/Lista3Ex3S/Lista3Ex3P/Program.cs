﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3Ex3P
{
    internal class Program
    {
        static void Main(string[] args)
        {
            char sexo;

            do
            {
                Console.WriteLine("Informe o sexo: Caso seja feminino digite (F) ou Caso seja masculino digite (M): ");
                sexo = char.Parse(Console.ReadLine());
            }

            while (sexo != 'M' && sexo != 'F');
        }
    }
}
