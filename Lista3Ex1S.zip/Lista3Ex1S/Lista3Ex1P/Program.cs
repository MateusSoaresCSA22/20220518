﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3Ex1P
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double val = 0;
            Console.Write("Informe o valor desejado: ");
            val = double.Parse(Console.ReadLine());
            do
            {
                Console.Write("Informe o valor desejado novamente: ");
                val = double.Parse(Console.ReadLine());
            }
            while (val < 0);
        }
    }
}
